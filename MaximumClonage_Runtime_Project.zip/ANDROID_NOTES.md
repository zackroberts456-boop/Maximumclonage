# Android / Mobile Notes

The foundation is authored for a **240×160 internal viewport** with integer scaling and fixed touch controls.

## Touch layout

- Left: fixed digital D-pad.
- Right upper: Special.
- Right/lower-right: Fire and Jump.
- Multi-touch is required so the player can move, aim, jump and shoot simultaneously.

## Export status

Android export presets/signing are not included in the foundation yet. They should be added only after the first real Godot runtime pass and once package identity (application ID, publisher/signing keys, icons) is decided.

The soundtrack is not an Android blocker; music slots can stay empty until the planned MIDI/chiptune arrangements are complete.
