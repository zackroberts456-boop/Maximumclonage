# Maximum Clonage — Asset Pipeline

## Source policy

Supplied production art is treated as source-of-truth artwork. Runtime processing may crop, key transparency, repack atlases or derive lower-resolution runtime textures, but must never overwrite the original source file.

Original supplied packs are kept under:

- `assets/source_archive/packs/MaximumClonage_Current_Player_Asset_Scans(1).zip`
- `assets/source_archive/packs/MaximumClonage_Clean_Level_Assets_For_Dev.zip`

`assets/source_archive/.gdignore` prevents Godot from importing the source archive as runtime content.

## Player atlas normalization

Source player atlases are 80 horizontal frames × 224×160, producing extremely wide 17,920×160 textures. For safer game/runtime use they are losslessly repacked into **10 columns × 8 rows**, 2,240×1,280 pixels.

- Source pixels remain untouched in `assets/source_archive/player_originals/`.
- Runtime copies are in `assets/players/`.
- `assets/players/runtime_atlas_manifest.json` records dimensions and per-frame SHA-256 hashes.
- `tools/normalize_runtime_atlases.py` can reproduce the packing.

No resampling is performed during repacking.

## Runtime derivations

Runtime art currently includes:

- player packed atlases and portraits
- a 240×160 title texture derived from supplied title art
- a 240×160 lab environment panel
- a small 16×16 runtime test tile atlas
- one isolated Clone Grunt test pose
- minimal projectile/pickup runtime primitives

The large menu/reference sheets remain reference/source material; they are not used as fake interactive screens.

## Explicitly excluded source images

The final six phone/gallery screenshots supplied after the production batches are intentionally excluded from the project and must not be used for extraction, reference, textures or placeholders:

- `1000073021.jpg`
- `1000073019.jpg`
- `1000073017.jpg`
- `1000073015.jpg`
- `1000073013.jpg`
- `1000073011.jpg`
