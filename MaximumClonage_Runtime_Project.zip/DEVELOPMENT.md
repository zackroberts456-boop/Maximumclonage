# Maximum Clonage — Development Log

## Current build

**Version:** `0.1.0-foundation`  
**Master engine target:** Godot 4.7.1 / GDScript  
**Internal resolution:** 240×160  
**Renderer:** GL Compatibility  
**Pixel presentation:** nearest-neighbor + integer viewport scaling  
**Physics target:** 60 Hz

This file is the running development record for the persistent Maximum Clonage master project. Future work should extend this project rather than restarting it.

## Current game flow

`Boot → Title Screen → Character Select → Test Room → Title Screen`

The test room is deliberately small. It proves the runtime architecture before full stage production begins.

## Implemented systems

### Rendering and project foundation

- Fixed 240×160 internal viewport.
- Integer viewport scaling.
- Nearest-neighbor texture filtering on runtime sprites and tile layers.
- 2D transform/vertex pixel snapping.
- GL Compatibility renderer selected for broad mobile support.
- Modular folder structure for actors, systems, data, UI, world, weapons and scenes.

### Player

- CharacterBody2D controller.
- Standardized 13×29 collision body across the roster.
- Six supplied player runtime atlases wired into the same controller.
- Slight character speed/fire-rate variation only; geometry remains standardized.
- Idle, run, shooting, jump and death runtime animation groups wired from Pass 67 atlas frames.
- Ladder frames are registered in SpriteFrames for later ladder gameplay integration.
- Horizontal movement.
- Variable-height jump.
- 0.10 s coyote time.
- 0.12 s jump input buffer.
- 8-way digital aim.
- Downward aim restricted to airborne state.
- Hold-to-fire.
- Light Fire-held aim lock / retreat strafe.
- Knockback and hit flashing.
- 1.0 s damage invulnerability.
- Pit/fall instant death.

### Input

A single `InputRouter` owns keyboard, gamepad and touch rules.

**Touch:** fixed left digital D-pad + right Fire / Jump / Special buttons. Multi-touch supports moving while holding Fire/Jump/Special.

**Keyboard:** WASD/arrows, J/Z Fire, K/X/Space Jump, L/C Special, Enter Start, Esc Back/Pause.

**Gamepad:** D-pad/left stick movement and aim, X/West Fire, A/South Jump, B/East Special, Start.

### Combat and weapons

- Unlimited-ammo default fire.
- Directional projectile spawning.
- Player and enemy projectile collision teams/layers.
- Working Spread special weapon as the first test pickup.
- Special weapon is cleared on death/respawn.
- Weapon controller is modular and ready for additional pickup types.

### Health, lives and continues

- Difficulty HP/lives values are centralized in `GameRules`.
- Easy: 16 HP / 5 lives.
- Normal: 12 HP / 3 lives.
- Hard: 10 HP / 3 lives.
- Nightmare: 8 HP / 2 lives; not exposed by the title difficulty cycle until campaign-unlock logic is connected to a finished campaign.
- Damage does not instantly kill except forced lethal hazards/falls.
- Full health on life respawn.
- Remaining lives respawn at last checkpoint.
- Out of lives triggers the unlimited-continue stage restart path.
- Temporary special weapon is lost on death.

### Difficulty behavior

The test enemy changes aggression instead of gaining a giant HP pool:

- Easy: slower movement/projectiles and longer firing interval.
- Normal: baseline.
- Hard: faster movement/projectiles and shorter firing interval.
- Nightmare: most aggressive current test values.

This is consistent with the project rule that higher difficulties should change pressure/patterns rather than create health sponges.

### Enemy AI

One functional Clone Grunt test enemy currently proves the enemy architecture:

- Patrol behavior.
- Player detection.
- Chase behavior.
- Stops and fires at close range.
- Contact damage.
- Projectile damage.
- Own health component.
- Hit reaction.
- Death/score/combo registration.
- Contact damage area disables on death.

The current test enemy deliberately uses one isolated production-art pose. Full enemy animation extraction is a next-stage asset task.

### World / levels

- Godot `TileSet` + `TileMapLayer` runtime tile level.
- Solid floor/platform collision.
- Scrollable 960×160 test room.
- Bottomless-pit gap.
- Functional checkpoint Area2D.
- Functional special-weapon pickup.
- End-of-room completion trigger.
- Camera limits and pixel-aligned tracking.

### Score and combo

- Enemy kills add score.
- Rapid kills raise score multiplier x1 → x5.
- Combo times out after 1.8 s.
- Taking damage resets combo.
- Combo affects score only, never damage.
- High score is persisted.

### Save data

`SaveManager` writes JSON to `user://maximum_clonage_save.json` and currently supports fields for:

- stages completed
- difficulty completion
- unlockable characters
- high scores
- secrets collected
- bosses defeated
- achievements
- campaign completion

Temporary health, lives and weapon pickups are intentionally not stored as campaign progression.

### UI

- Functional title screen built over supplied title artwork.
- Difficulty selector.
- Functional six-character selection screen using production player atlas portraits.
- Runtime HUD with character, HP, lives, score, combo and special weapon.
- Debug overlay.
- Fixed mobile touch controls.

Supplied menu mockups are retained as references/source art but are **not** being substituted for functional menus.

### Audio

- Global `AudioManager` with music and SFX players.
- No soundtrack is bundled yet by design.
- The future MIDI/chiptune versions of the Maximum Clonage album can be dropped into the music layer later.
- Production SFX still need to be supplied or created.

## Asset integration performed

### Player art

The supplied Pass 67 player pack contains six 80-frame runtime atlases at 224×160 per source frame. The source atlases were preserved untouched under `assets/source_archive/player_originals/`.

For runtime use, all six were **losslessly repacked** from extremely wide 80×1 strips into 10×8 sheets. No player pixels were redrawn. A validation pass compared the SHA-256 hash of the RGBA pixel data for every source frame against its packed frame: **480/480 frames matched**.

Runtime sheets live in `assets/players/*_runtime_80frames_packed.png`.

### Environment and UI art

- Runtime title background derived from the supplied clean title-background source by crop/nearest resize.
- Runtime lab panel/floor material derived from supplied clean environment art.
- Source packs remain untouched and archived.
- Some files in the supplied `tiles_and_platforms` category are actually reference/contact sheets rather than production-ready tile atlases. Those are retained for reference but not treated as clean collision tiles.

### Enemy art

- First complete Clone Grunt pose isolated from a supplied production sprite sheet for the test enemy.
- Full enemy animation extraction/normalization is not yet complete.

### Explicit exclusions

The six final phone/gallery screenshots the user instructed us not to use are excluded from the production pool and are not copied into this master project.

## Known issues / unfinished systems

1. **Engine runtime playtest is still required.** The current build environment does not contain a Godot executable. Attempts to obtain the official Linux editor binary were blocked by the container's download/redirect restrictions. Structural/project/asset validation has been run, but this build must still receive a real Godot editor/headless launch pass before it is considered runtime-verified.
2. The Pass 67 player atlas animation ranges are mapped from the numbered runtime scan and are sufficient for the foundation, but the entire 80-frame semantic map needs a formal per-character audit before final animation timing/state work.
3. Ladder art is loaded into the animation resource but actual ladder collision/mount/dismount gameplay is not active yet.
4. The test Clone Grunt is AI-functional but currently uses a static isolated production pose. Full enemy animation sheets need normalization.
5. Boss framework/fights are not part of this first playable room yet.
6. Two-player co-op is specified but not implemented in the first foundation pass.
7. Health and 1-Up pickup logic/art are not yet placed in the room.
8. Only Spread is implemented as a special weapon so far. Rapid, Heavy, Beam, Explosive, Piercing, Continuous/Flame and Homing remain future weapon modules.
9. The three-button mobile scheme creates one design intersection that must eventually be finalized: the `Special` button currently fires the equipped special weapon; character-specific unique abilities need a consistent trigger rule without adding a fourth action button.
10. No production sound effects or soundtrack are bundled yet.
11. Android signing/export presets are intentionally deferred until runtime playtesting and package identity are ready.

## Asset requirements still useful

Highest-value future inputs are:

- clean, isolated environment tiles/platform/ladder/door/hazard atlases if better sources exist
- original enemy runtime atlases or clean frame sheets for each archetype
- original boss runtime atlases or clean frame sheets
- weapon pickup icons and isolated projectile/VFX atlases where available
- final SFX later
- MIDI/chiptune soundtrack later

Do **not** redraw supplied production character art unless explicitly requested.

## Next development order

1. Run the foundation in the actual Godot 4.7.1 editor/headless runtime and fix any parser/runtime/import issues.
2. Formalize the 80-frame player animation map and activate ladder movement.
3. Normalize the enemy asset pool into named animation atlases and implement 2–3 core enemy archetypes.
4. Build Stage 1 as the first real 10–20 minute vertical slice using clean modular tiles/parallax layers.
5. Add health/1-Up/weapon pickup families and remaining special weapons.
6. Implement the first dedicated 3-state/phase boss with telegraphed patterns.
7. Add local 2-player shared-camera co-op and co-op boss scaling.
8. Add pause/options and control remapping where appropriate without changing the fixed mobile layout.
9. Integrate production SFX.
10. Create Android export preset/APK test builds; soundtrack can remain absent until MIDI arrangements are ready.

## Regression rule

New work must not remove working systems unless technically required. Any required regression/change should be documented here before replacing existing behavior.
