# Maximum Clonage — Canonical Gameplay Rules

These rules are considered locked until explicitly changed by the project owner.

## Core philosophy

Maximum Clonage combines **Mega Man-style readable level design, health, bosses and checkpoints** with **Contra-style speed, shooting, enemy density, weapon pickups and two-player action**. Difficulty must come from learning patterns and mastering movement—not tedious repetition, giant enemy health pools, or unfair attacks.

Movement and collision geometry must be standardized enough that every normal stage can be authored once and completed by every playable character.

## Player health

- Normal: 12 HP.
- Basic attacks: generally 1 HP.
- Strong enemy attacks/hazards: generally 2 HP.
- Heavy attacks/major hazards: up to 3 HP.
- Enemy contact damages rather than instantly kills.
- Bottomless pits, crushing traps and selected environmental hazards are instant death.
- Approximately 1 second of invulnerability after damage.

## Lives / continues / checkpoints

- Normal: 3 lives at stage start.
- Losing all HP costs one life.
- Unlimited continues.
- Remaining lives respawn at latest checkpoint with full health.
- Normal stages target roughly 2–3 checkpoints, with one generally before the boss.
- Using a continue restarts the current stage and resets its checkpoints.
- Boss death with lives remaining respawns immediately before the boss.
- Losing all lives never erases cleared campaign stages.

## Playable characters

Every character can complete every stage.

Allowed differentiation:

- signature/default weapon
- small movement-speed differences
- small damage differences
- small firing-speed differences
- unique special ability

Required standardization:

- nearly identical jump height
- functionally equivalent hitboxes
- no character-required normal progression
- no extreme stat gaps that create a dominant character

## Weapons

- Every character always owns an unlimited-ammo default/signature weapon.
- Special weapon pickups are stronger and replace the currently held special weapon.
- Death removes the special weapon and respawns the player with their default weapon.
- Temporary fire-rate/projectile-power upgrades may last until death.

Planned special weapon families: Spread, Rapid, Heavy Projectile, Laser/Beam, Explosive, Piercing, Continuous/Flame, Homing.

## Health / lives pickups

- Small health: +2 HP.
- Large health: +5 HP.
- Rare full health: restore all.
- Boss arenas do not continuously spawn health.
- Rare 1-Ups can be hidden or earned by score milestones.
- Maximum stored lives: 9.

## Bosses

- Every stage has a dedicated boss.
- Bosses have substantially larger health bars than players.
- Roughly three recognizable phases/behavior states.
- Attacks are telegraphed.
- Patterns become more aggressive as health falls.
- Difficulty is learned patterns, not random unavoidable hits.
- Boss victory restores player health before the next stage.

## Stage structure

Typical flow:

`Opening → escalation → checkpoint → new mechanic/enemy combination → checkpoint → difficult final section → boss`

First successful clear target: roughly 10–20 minutes.

## Enemy behavior

- Regular enemies may respawn after sufficient backtracking.
- Tough enemies/minibosses generally stay dead until player death.
- Attacks should be readable.
- Do not spawn directly on top of the player.
- Placement rewards memorization and quick reactions.

## Score / combo

Score is for replay value, not progression gates.

Score sources include kills, elites, bosses, secrets, destroyables, stage clear, health/lives remaining and completion time, plus no-death and perfect-boss bonuses.

Rapid kills create a score multiplier x1 → x5. Taking damage or allowing the combo timer to expire resets it. Combo never modifies combat damage.

## Difficulty

**Easy:** 16 HP, 5 lives, more health, reduced pressure/damage, slower bosses.

**Normal:** 12 HP, 3 lives, intended experience.

**Hard:** 10 HP, 3 lives, more aggressive enemies/faster boss patterns, fewer drops, additional placements.

**Clonage / Nightmare:** unlocked after game completion; 8 HP, 2 lives, heavier placement, faster projectiles, more complex boss patterns, limited healing, extra boss attacks; friendly fire may be recommended but is optional.

Harder modes change patterns/pressure rather than turning enemies into health sponges.

## Two-player co-op

- Simultaneous local play.
- Independent character, health and lives.
- Shared progression/checkpoints.
- Shared camera limits excessive separation.
- A dead player with remaining lives respawns near the survivor when safe.
- A player with no lives can rejoin at the next checkpoint.
- Continue occurs only after both players are out of lives.
- Friendly fire OFF by default; optional setting.
- Players do not physically block one another.
- Boss HP increases roughly 50–70% in two-player, not 100%, with somewhat more aggressive patterns.

## Save rules

Auto-save long-term progression such as stage clears, difficulty clears, unlocks, high scores, secrets, bosses, achievements/extras.

Do not persist temporary stage health, lives or special weapon pickups between stages.

## Control law

Mobile uses a fixed digital touchscreen D-pad on the left and exactly three action buttons on the right: **Fire, Jump, Special**.

- No twin-stick aiming.
- D-pad controls movement and Contra-style 8-way shooting.
- Left/right/up/diagonal shooting on ground; downward shooting while airborne.
- Hold Fire = continuous fire + light aim-lock/strafe so the player can retreat while maintaining firing direction.
- Variable jump height.
- Coyote time.
- Jump input buffering.
- Simultaneous movement, aiming, jumping and shooting must work.
- Bluetooth/USB controllers obey the same underlying control rules.
