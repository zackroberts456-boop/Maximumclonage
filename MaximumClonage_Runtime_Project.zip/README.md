# Maximum Clonage — Godot Master Project

**Foundation build:** `0.1.0-foundation`

This repository is the persistent master project for **Maximum Clonage**. It is a real Godot 2D project built around the supplied production art, a 240×160 internal game resolution, nearest-neighbor rendering, tile collision, keyboard/gamepad/touch input, and modular gameplay systems.

## Open and run

1. Open this folder in **Godot 4.7.1**.
2. Press **F6/F5** or run the project normally.
3. Flow: **Boot → Title → Character Select → Test Room**.

No soundtrack is required yet. The `AudioManager` is already present so the planned MIDI/chiptune Maximum Clonage soundtrack can be integrated later without restructuring stages.

## Foundation controls

| Action | Keyboard | Gamepad | Touch |
|---|---|---|---|
| Move / Aim | WASD or arrows | D-pad / left stick | fixed digital D-pad |
| Fire | J / Z | X / West face button | Fire |
| Jump | K / X / Space | A / South face button | Jump |
| Special | L / C | B / East face button | Special |
| Start | Enter | Start | UI |
| Back / Pause | Esc | Start | future pause UI |
| Debug hitboxes | F2 | — | — |
| Debug overlay | F3 | — | — |
| Show touch controls on desktop | F4 | — | — |

Fire supports hold-to-fire. Holding Fire also enables light aim-lock/strafe behavior. Aim is digital 8-way; downward shooting is allowed while airborne.

## What is playable now

- Functional title screen and difficulty selection.
- Functional six-character select using supplied character art.
- Player movement, variable jump, coyote time, jump buffering.
- 8-way aiming, hold-to-fire, aim-lock/strafe.
- Tile-based scrolling test room with platforms and a bottomless pit.
- Camera, collision, checkpoint, damage, 1-second invulnerability, lives, death and restart.
- One test Clone Grunt with patrol/chase/shoot/contact AI.
- Default unlimited-ammo weapon and a working Spread special-weapon pickup.
- Score/combo foundation and JSON save data.
- Fixed mobile D-pad plus Fire / Jump / Special multi-touch controls.
- Keyboard and USB/Bluetooth-controller input through the same action layer.
- Debug overlay and collision visualization.

See [`DEVELOPMENT.md`](DEVELOPMENT.md) for exact status, known issues, asset requirements, and next work.

## Project structure

```text
assets/
  enemies/          runtime enemy art
  environment/      runtime stage art / tiles
  players/          normalized runtime player atlases
  ui/               runtime UI art
  source_archive/   untouched supplied sources; ignored by Godot importer
scenes/              boot / title / select / test room
scripts/
  actors/            players and enemies
  components/        reusable health/etc.
  core/              state, input, save, audio
  data/              canonical rules and character data
  scenes/            scene controllers
  ui/                HUD, touch, debug
  weapons/           weapons/projectiles
  world/             checkpoints/pickups
 tools/               asset normalization and validation
```

## Source-asset protection

The original user-supplied archives are preserved in `assets/source_archive/packs/`. Source art is never overwritten by runtime processing. The six final phone/gallery screenshots explicitly excluded by the user are **not** part of the project asset pool.
