extends CharacterBody2D

const HealthComponent = preload("res://scripts/components/health_component.gd")
const GameRules = preload("res://scripts/data/game_rules.gd")
const Projectile = preload("res://scripts/weapons/projectile.gd")

var spawn_x = 0.0
var patrol_direction = -1
var speed = 24.0
var fire_interval = 1.05
var projectile_speed = 115.0
var shoot_timer = 0.5
var dead = false
var health
var sprite
var damage_area

func _ready():
    add_to_group("enemies")
    collision_layer = 4
    collision_mask = 1
    spawn_x = global_position.x
    var difficulty = GameRules.difficulty_data(GameState.difficulty)
    speed *= float(difficulty["enemy_speed_scale"])
    fire_interval *= float(difficulty["enemy_fire_interval_scale"])
    projectile_speed *= float(difficulty["enemy_projectile_speed_scale"])

    var collider = CollisionShape2D.new()
    var shape = RectangleShape2D.new()
    shape.size = Vector2(15, 28)
    collider.shape = shape
    collider.position = Vector2(0, -2)
    add_child(collider)

    sprite = Sprite2D.new()
    sprite.texture = load("res://assets/enemies/clone_grunt_idle.png")
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    sprite.scale = Vector2(0.5, 0.5)
    sprite.position = Vector2(0, -17)
    add_child(sprite)

    health = HealthComponent.new()
    health.configure(4, 0.10)
    add_child(health)
    health.died.connect(_on_died)

    damage_area = Area2D.new()
    damage_area.collision_layer = 32
    damage_area.collision_mask = 2
    var damage_shape = CollisionShape2D.new()
    var area_shape = RectangleShape2D.new()
    area_shape.size = Vector2(17, 30)
    damage_shape.shape = area_shape
    damage_shape.position = Vector2(0, -2)
    damage_area.add_child(damage_shape)
    add_child(damage_area)
    damage_area.body_entered.connect(_on_damage_area_body_entered)

func _physics_process(delta):
    if dead:
        return
    if not is_on_floor():
        velocity.y += GameRules.GRAVITY * delta

    var player = get_tree().get_first_node_in_group("players")
    var desired_x = patrol_direction * speed
    if player != null and not player.dead:
        var dx = player.global_position.x - global_position.x
        if abs(dx) < 115.0:
            sprite.flip_h = dx < 0.0
            if abs(dx) > 45.0:
                desired_x = sign(dx) * speed
            else:
                desired_x = 0.0
                _try_shoot(player)
        else:
            _patrol()
    else:
        _patrol()

    velocity.x = desired_x
    shoot_timer = max(0.0, shoot_timer - delta)
    move_and_slide()

    if abs(global_position.x - spawn_x) > 42.0 and (player == null or abs(player.global_position.x - global_position.x) >= 115.0):
        patrol_direction *= -1

    if global_position.y > 190.0:
        queue_free()
    if GameState.debug_collision_visible:
        queue_redraw()

func _patrol():
    if patrol_direction == 0:
        patrol_direction = -1
    sprite.flip_h = patrol_direction < 0

func _try_shoot(player):
    if shoot_timer > 0.0:
        return
    shoot_timer = fire_interval
    var direction = (player.global_position + Vector2(0, -8) - (global_position + Vector2(0, -9))).normalized()
    var projectile = Projectile.new()
    projectile.setup(direction, projectile_speed, 1, "enemy")
    get_tree().current_scene.add_child(projectile)
    projectile.global_position = global_position + Vector2(sign(direction.x) * 10.0, -9)

func take_damage(amount, source_position = Vector2.ZERO):
    if dead:
        return false
    if health.damage(amount):
        var knock = sign(global_position.x - source_position.x)
        velocity.x = knock * 30.0
        sprite.modulate = Color(1.0, 1.0, 1.0, 0.55)
        var tween = create_tween()
        tween.tween_property(sprite, "modulate", Color.WHITE, 0.10)
        return true
    return false

func _on_damage_area_body_entered(body):
    if body.is_in_group("players") and body.has_method("take_damage"):
        body.take_damage(1, global_position)

func _on_died():
    dead = true
    collision_layer = 0
    collision_mask = 0
    if damage_area != null:
        damage_area.set_deferred("monitoring", false)
        damage_area.set_deferred("monitorable", false)
    GameState.register_enemy_kill(100)
    var tween = create_tween()
    tween.tween_property(sprite, "modulate", Color(0.3, 1.0, 0.3, 0.0), 0.25)
    tween.finished.connect(queue_free)

func _draw():
    if GameState.debug_collision_visible:
        draw_rect(Rect2(Vector2(-7.5, -16.0), Vector2(15, 28)), Color(1.0, 0.2, 0.2, 0.55), false, 1.0)
