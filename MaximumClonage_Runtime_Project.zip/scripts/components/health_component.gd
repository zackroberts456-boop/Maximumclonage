extends Node

signal health_changed(current_hp, max_hp)
signal damaged(amount)
signal died

var max_hp = 1
var current_hp = 1
var invulnerability_duration = 0.0
var invulnerability_left = 0.0

func configure(maximum, invulnerability_seconds = 0.0):
    max_hp = max(1, int(maximum))
    current_hp = max_hp
    invulnerability_duration = max(0.0, float(invulnerability_seconds))

func _process(delta):
    if invulnerability_left > 0.0:
        invulnerability_left = max(0.0, invulnerability_left - delta)

func damage(amount):
    if current_hp <= 0 or invulnerability_left > 0.0:
        return false
    var applied = max(0, int(amount))
    current_hp = max(0, current_hp - applied)
    invulnerability_left = invulnerability_duration
    damaged.emit(applied)
    health_changed.emit(current_hp, max_hp)
    if current_hp <= 0:
        died.emit()
    return true

func heal(amount):
    if current_hp <= 0:
        return
    current_hp = min(max_hp, current_hp + max(0, int(amount)))
    health_changed.emit(current_hp, max_hp)

func restore_full():
    current_hp = max_hp
    invulnerability_left = 0.0
    health_changed.emit(current_hp, max_hp)

func force_kill():
    if current_hp <= 0:
        return
    current_hp = 0
    invulnerability_left = 0.0
    health_changed.emit(current_hp, max_hp)
    died.emit()

func is_invulnerable():
    return invulnerability_left > 0.0
