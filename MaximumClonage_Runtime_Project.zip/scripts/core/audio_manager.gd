extends Node

# The soundtrack is intentionally deferred until the MIDI/chiptune Maximum Clonage arrangements exist.
# This manager is production plumbing so music can be added later without rewriting scenes.
var music_player
var sfx_player

func _ready():
    music_player = AudioStreamPlayer.new()
    music_player.name = "Music"
    add_child(music_player)
    sfx_player = AudioStreamPlayer.new()
    sfx_player.name = "SFX"
    add_child(sfx_player)

func play_music(stream, volume_db = -6.0):
    if stream == null:
        return
    music_player.stream = stream
    music_player.volume_db = volume_db
    music_player.play()

func stop_music():
    music_player.stop()

func play_sfx(stream, volume_db = 0.0):
    if stream == null:
        return
    sfx_player.stream = stream
    sfx_player.volume_db = volume_db
    sfx_player.play()
