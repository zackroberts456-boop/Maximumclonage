extends Node

const GameRules = preload("res://scripts/data/game_rules.gd")

signal health_changed(current_hp, max_hp)
signal lives_changed(lives)
signal score_changed(score)
signal checkpoint_changed(position)
signal combo_changed(multiplier)

const DIFFICULTIES = GameRules.DIFFICULTIES

var difficulty = "normal"
var selected_character = "nada"
var current_stage = ""
var stage_start_position = Vector2(40, 112)
var checkpoint_position = Vector2(40, 112)
var max_hp = 12
var current_hp = 12
var lives = 3
var score = 0
var combo_multiplier = 1
var combo_time_left = 0.0
var debug_overlay_visible = true
var debug_collision_visible = false
var touch_controls_visible = false

func _ready():
    set_process(true)
    touch_controls_visible = OS.has_feature("mobile") or bool(ProjectSettings.get_setting("maximum_clonage/debug/show_touch_controls_on_desktop", false))

func _process(delta):
    if combo_time_left > 0.0:
        combo_time_left = max(0.0, combo_time_left - delta)
        if combo_time_left <= 0.0 and combo_multiplier != 1:
            combo_multiplier = 1
            combo_changed.emit(combo_multiplier)

func set_difficulty(value):
    if DIFFICULTIES.has(value):
        difficulty = value

func begin_stage(stage_id, start_position):
    current_stage = stage_id
    stage_start_position = start_position
    checkpoint_position = start_position
    var rules = DIFFICULTIES[difficulty]
    max_hp = int(rules["hp"])
    current_hp = max_hp
    lives = int(rules["lives"])
    score = 0
    combo_multiplier = 1
    combo_time_left = 0.0
    health_changed.emit(current_hp, max_hp)
    lives_changed.emit(lives)
    score_changed.emit(score)
    combo_changed.emit(combo_multiplier)

func set_player_hp(value):
    current_hp = clamp(int(value), 0, max_hp)
    health_changed.emit(current_hp, max_hp)

func lose_life():
    lives = max(0, lives - 1)
    current_hp = max_hp
    reset_combo()
    lives_changed.emit(lives)
    health_changed.emit(current_hp, max_hp)
    return lives > 0

func continue_stage():
    var rules = DIFFICULTIES[difficulty]
    lives = int(rules["lives"])
    current_hp = max_hp
    checkpoint_position = stage_start_position
    reset_combo()
    lives_changed.emit(lives)
    health_changed.emit(current_hp, max_hp)
    checkpoint_changed.emit(checkpoint_position)

func set_checkpoint(value):
    checkpoint_position = value
    checkpoint_changed.emit(checkpoint_position)

func add_score(points):
    score += int(points)
    score_changed.emit(score)

func register_enemy_kill(base_points = 100):
    if combo_time_left > 0.0:
        combo_multiplier = min(GameRules.COMBO_MAX, combo_multiplier + 1)
    else:
        combo_multiplier = 1
    combo_time_left = GameRules.COMBO_TIMEOUT
    add_score(base_points * combo_multiplier)
    combo_changed.emit(combo_multiplier)

func reset_combo():
    combo_multiplier = 1
    combo_time_left = 0.0
    combo_changed.emit(combo_multiplier)
