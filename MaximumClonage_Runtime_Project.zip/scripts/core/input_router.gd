extends Node

var touch_move = Vector2.ZERO
var touch_buttons = {}
var touch_press_time = {}
var touch_release_time = {}
var touch_press_consumed = {}
var touch_release_consumed = {}

func _ready():
    _register_default_actions()

func _register_default_actions():
    _ensure_action("move_left")
    _ensure_action("move_right")
    _ensure_action("move_up")
    _ensure_action("move_down")
    _ensure_action("fire")
    _ensure_action("jump")
    _ensure_action("special")
    _ensure_action("start")
    _ensure_action("pause")
    _ensure_action("debug_overlay")
    _ensure_action("debug_collision")
    _ensure_action("debug_touch")

    _add_key("move_left", KEY_A)
    _add_key("move_left", KEY_LEFT)
    _add_key("move_right", KEY_D)
    _add_key("move_right", KEY_RIGHT)
    _add_key("move_up", KEY_W)
    _add_key("move_up", KEY_UP)
    _add_key("move_down", KEY_S)
    _add_key("move_down", KEY_DOWN)

    _add_key("fire", KEY_J)
    _add_key("fire", KEY_Z)
    _add_key("jump", KEY_K)
    _add_key("jump", KEY_X)
    _add_key("jump", KEY_SPACE)
    _add_key("special", KEY_L)
    _add_key("special", KEY_C)
    _add_key("start", KEY_ENTER)
    _add_key("pause", KEY_ESCAPE)
    _add_key("debug_overlay", KEY_F3)
    _add_key("debug_collision", KEY_F2)
    _add_key("debug_touch", KEY_F4)

    _add_joy_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
    _add_joy_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
    _add_joy_axis("move_up", JOY_AXIS_LEFT_Y, -1.0)
    _add_joy_axis("move_down", JOY_AXIS_LEFT_Y, 1.0)
    _add_joy_button("move_left", JOY_BUTTON_DPAD_LEFT)
    _add_joy_button("move_right", JOY_BUTTON_DPAD_RIGHT)
    _add_joy_button("move_up", JOY_BUTTON_DPAD_UP)
    _add_joy_button("move_down", JOY_BUTTON_DPAD_DOWN)
    _add_joy_button("fire", JOY_BUTTON_X)
    _add_joy_button("jump", JOY_BUTTON_A)
    _add_joy_button("special", JOY_BUTTON_B)
    _add_joy_button("start", JOY_BUTTON_START)
    _add_joy_button("pause", JOY_BUTTON_START)

func _ensure_action(action_name):
    if not InputMap.has_action(action_name):
        InputMap.add_action(action_name, 0.35)

func _event_already_present(action_name, event):
    for existing in InputMap.action_get_events(action_name):
        if existing.as_text() == event.as_text():
            return true
    return false

func _add_key(action_name, keycode):
    var event = InputEventKey.new()
    event.physical_keycode = keycode
    if not _event_already_present(action_name, event):
        InputMap.action_add_event(action_name, event)

func _add_joy_button(action_name, button_index):
    var event = InputEventJoypadButton.new()
    event.button_index = button_index
    if not _event_already_present(action_name, event):
        InputMap.action_add_event(action_name, event)

func _add_joy_axis(action_name, axis_index, axis_value):
    var event = InputEventJoypadMotion.new()
    event.axis = axis_index
    event.axis_value = axis_value
    if not _event_already_present(action_name, event):
        InputMap.action_add_event(action_name, event)

func set_touch_move(value):
    touch_move = Vector2(sign(value.x), sign(value.y))

func set_touch_action(action_name, pressed):
    var was_pressed = bool(touch_buttons.get(action_name, false))
    if was_pressed == pressed:
        return
    touch_buttons[action_name] = pressed
    var now = Time.get_ticks_msec()
    if pressed:
        touch_press_time[action_name] = now
        touch_press_consumed[action_name] = false
    else:
        touch_release_time[action_name] = now
        touch_release_consumed[action_name] = false

func clear_touch():
    touch_move = Vector2.ZERO
    for key in touch_buttons.keys():
        touch_buttons[key] = false

func get_move_vector():
    if touch_move != Vector2.ZERO:
        return touch_move
    var x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
    var y = Input.get_action_strength("move_down") - Input.get_action_strength("move_up")
    var result = Vector2.ZERO
    if abs(x) > 0.25:
        result.x = sign(x)
    if abs(y) > 0.25:
        result.y = sign(y)
    return result

func is_action_pressed_mc(action_name):
    return bool(touch_buttons.get(action_name, false)) or Input.is_action_pressed(action_name)

func is_action_just_pressed_mc(action_name):
    if Input.is_action_just_pressed(action_name):
        return true
    if not touch_press_time.has(action_name) or bool(touch_press_consumed.get(action_name, false)):
        return false
    if Time.get_ticks_msec() - int(touch_press_time[action_name]) > 120:
        return false
    touch_press_consumed[action_name] = true
    return true

func is_action_just_released_mc(action_name):
    if Input.is_action_just_released(action_name):
        return true
    if not touch_release_time.has(action_name) or bool(touch_release_consumed.get(action_name, false)):
        return false
    if Time.get_ticks_msec() - int(touch_release_time[action_name]) > 120:
        return false
    touch_release_consumed[action_name] = true
    return true
