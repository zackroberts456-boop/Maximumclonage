extends Node

const SAVE_PATH = "user://maximum_clonage_save.json"

var data = {
    "version": 1,
    "stages_completed": {},
    "difficulty_completion": {},
    "unlockable_characters": [],
    "high_scores": {},
    "secrets_collected": {},
    "bosses_defeated": {},
    "achievements": [],
    "campaign_complete": false
}

func _ready():
    load_save()

func load_save():
    if not FileAccess.file_exists(SAVE_PATH):
        save_now()
        return
    var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if typeof(parsed) == TYPE_DICTIONARY:
        for key in data.keys():
            if parsed.has(key):
                data[key] = parsed[key]

func save_now():
    var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_warning("Maximum Clonage: could not write save file")
        return
    file.store_string(JSON.stringify(data, "  "))

func mark_stage_completed(stage_id):
    data["stages_completed"][stage_id] = true
    save_now()

func submit_high_score(stage_id, value):
    var old_value = int(data["high_scores"].get(stage_id, 0))
    if int(value) > old_value:
        data["high_scores"][stage_id] = int(value)
        save_now()

func is_nightmare_unlocked():
    return bool(data.get("campaign_complete", false))
