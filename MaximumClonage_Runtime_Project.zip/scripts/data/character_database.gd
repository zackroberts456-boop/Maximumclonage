extends RefCounted

const ORDER = ["nada", "bella", "andre", "lawrence", "vance", "zack"]

const DATA = {
    "nada": {
        "display_name": "NADA",
        "atlas": "res://assets/players/nada_runtime_80frames_packed.png",
        "portrait": "res://assets/ui/nada_portrait.png",
        "move_speed": 72.0,
        "fire_interval": 0.18,
        "projectile_damage": 1
    },
    "bella": {
        "display_name": "BELLA",
        "atlas": "res://assets/players/bella_runtime_80frames_packed.png",
        "portrait": "res://assets/ui/bella_portrait.png",
        "move_speed": 74.0,
        "fire_interval": 0.17,
        "projectile_damage": 1
    },
    "andre": {
        "display_name": "ANDRE",
        "atlas": "res://assets/players/andre_runtime_80frames_packed.png",
        "portrait": "res://assets/ui/andre_portrait.png",
        "move_speed": 70.0,
        "fire_interval": 0.21,
        "projectile_damage": 1
    },
    "lawrence": {
        "display_name": "LAWRENCE",
        "atlas": "res://assets/players/lawrence_runtime_80frames_packed.png",
        "portrait": "res://assets/ui/lawrence_portrait.png",
        "move_speed": 72.0,
        "fire_interval": 0.18,
        "projectile_damage": 1
    },
    "vance": {
        "display_name": "VANCE",
        "atlas": "res://assets/players/vance_runtime_80frames_packed.png",
        "portrait": "res://assets/ui/vance_portrait.png",
        "move_speed": 73.0,
        "fire_interval": 0.18,
        "projectile_damage": 1
    },
    "zack": {
        "display_name": "ZACK",
        "atlas": "res://assets/players/zack_runtime_80frames_packed.png",
        "portrait": "res://assets/ui/zack_portrait.png",
        "move_speed": 72.0,
        "fire_interval": 0.18,
        "projectile_damage": 1
    }
}

static func get_character(character_id):
    return DATA.get(character_id, DATA["nada"])

static func get_order():
    return ORDER.duplicate()
