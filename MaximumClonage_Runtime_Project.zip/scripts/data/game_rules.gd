extends RefCounted

# Canonical foundation rules. Keep stage geometry compatible with every character.
const INTERNAL_RESOLUTION = Vector2i(240, 160)
const STANDARD_HITBOX_SIZE = Vector2(13, 29)
const GRAVITY = 520.0
const JUMP_SPEED = 178.0
const COYOTE_TIME = 0.10
const JUMP_BUFFER_TIME = 0.12
const PLAYER_INVULNERABILITY = 1.0
const MAX_STORED_LIVES = 9
const SMALL_HEALTH = 2
const LARGE_HEALTH = 5
const COMBO_TIMEOUT = 1.8
const COMBO_MAX = 5

const DIFFICULTIES = {
    "easy": {
        "hp": 16,
        "lives": 5,
        "enemy_speed_scale": 0.85,
        "enemy_fire_interval_scale": 1.18,
        "enemy_projectile_speed_scale": 0.90,
        "health_drop_scale": 1.35
    },
    "normal": {
        "hp": 12,
        "lives": 3,
        "enemy_speed_scale": 1.0,
        "enemy_fire_interval_scale": 1.0,
        "enemy_projectile_speed_scale": 1.0,
        "health_drop_scale": 1.0
    },
    "hard": {
        "hp": 10,
        "lives": 3,
        "enemy_speed_scale": 1.15,
        "enemy_fire_interval_scale": 0.82,
        "enemy_projectile_speed_scale": 1.12,
        "health_drop_scale": 0.65
    },
    "nightmare": {
        "hp": 8,
        "lives": 2,
        "enemy_speed_scale": 1.30,
        "enemy_fire_interval_scale": 0.68,
        "enemy_projectile_speed_scale": 1.25,
        "health_drop_scale": 0.35
    }
}

static func difficulty_data(id):
    return DIFFICULTIES.get(id, DIFFICULTIES["normal"])
