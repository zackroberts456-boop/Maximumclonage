extends Node

func _ready():
    # Source resolution is fixed at 240x160. project.godot handles integer viewport scaling.
    await get_tree().process_frame
    get_tree().change_scene_to_file("res://scenes/title_screen.tscn")
