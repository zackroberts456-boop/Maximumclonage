extends Node2D

const Player = preload("res://scripts/actors/player.gd")
const TestEnemy = preload("res://scripts/actors/test_enemy.gd")
const Checkpoint = preload("res://scripts/world/checkpoint.gd")
const WeaponPickup = preload("res://scripts/world/weapon_pickup.gd")
const Hud = preload("res://scripts/ui/hud.gd")
const DebugOverlay = preload("res://scripts/ui/debug_overlay.gd")
const TouchControls = preload("res://scripts/ui/touch_controls.gd")

var player
var message_label
var handling_death = false
var stage_complete = false

func _ready():
    GameState.begin_stage("test_room", Vector2(40, 116))
    _build_background()
    _build_tile_level()
    _spawn_gameplay()
    _build_ui()

func _process(_delta):
    if stage_complete:
        return
    if player != null and player.global_position.x > 925.0:
        _complete_test_room()

func _build_background():
    var texture = load("res://assets/environment/lab_panel_240x160.png")
    for i in range(4):
        var sprite = Sprite2D.new()
        sprite.texture = texture
        sprite.centered = false
        sprite.position = Vector2(i * 240, 0)
        sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
        sprite.z_index = -20
        add_child(sprite)

func _build_tile_level():
    var tile_set = TileSet.new()
    tile_set.tile_size = Vector2i(16, 16)
    tile_set.add_physics_layer()
    tile_set.set_physics_layer_collision_layer(0, 1)
    tile_set.set_physics_layer_collision_mask(0, 0)

    var source = TileSetAtlasSource.new()
    source.texture = load("res://assets/environment/lab_tiles_16.png")
    source.texture_region_size = Vector2i(16, 16)
    source.create_tile(Vector2i(0, 0))
    source.create_tile(Vector2i(1, 0))

    for coords in [Vector2i(0, 0), Vector2i(1, 0)]:
        var tile_data = source.get_tile_data(coords, 0)
        tile_data.set_collision_polygons_count(0, 1)
        tile_data.set_collision_polygon_points(0, 0, PackedVector2Array([
            Vector2(-8, -8), Vector2(8, -8), Vector2(8, 8), Vector2(-8, 8)
        ]))

    var source_id = tile_set.add_source(source)
    var tile_layer = TileMapLayer.new()
    tile_layer.name = "CollisionTiles"
    tile_layer.tile_set = tile_set
    tile_layer.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    add_child(tile_layer)

    for x in range(60):
        if x < 20 or x > 22:
            tile_layer.set_cell(Vector2i(x, 9), source_id, Vector2i(0, 0), 0)
    for x in range(8, 15):
        tile_layer.set_cell(Vector2i(x, 6), source_id, Vector2i(1, 0), 0)
    for x in range(27, 34):
        tile_layer.set_cell(Vector2i(x, 7), source_id, Vector2i(1, 0), 0)
    for x in range(41, 49):
        tile_layer.set_cell(Vector2i(x, 5), source_id, Vector2i(1, 0), 0)

func _spawn_gameplay():
    player = Player.new()
    player.setup(GameState.selected_character)
    player.global_position = GameState.stage_start_position
    add_child(player)
    player.died.connect(_on_player_died)

    var enemy = TestEnemy.new()
    enemy.global_position = Vector2(178, 116)
    add_child(enemy)

    var pickup = WeaponPickup.new()
    pickup.global_position = Vector2(285, 102)
    add_child(pickup)

    var checkpoint = Checkpoint.new()
    checkpoint.setup(Vector2(432, 116))
    checkpoint.global_position = Vector2(424, 112)
    add_child(checkpoint)

func _build_ui():
    var hud = Hud.new()
    hud.setup(player)
    add_child(hud)

    var debug = DebugOverlay.new()
    debug.setup(player)
    add_child(debug)

    var touch_layer = CanvasLayer.new()
    touch_layer.layer = 40
    add_child(touch_layer)
    var touch = TouchControls.new()
    touch_layer.add_child(touch)

    var message_layer = CanvasLayer.new()
    message_layer.layer = 45
    add_child(message_layer)
    message_label = Label.new()
    message_label.position = Vector2(30, 72)
    message_label.size = Vector2(180, 20)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 8)
    message_label.add_theme_color_override("font_color", Color(0.75, 1.0, 0.25))
    message_label.add_theme_color_override("font_shadow_color", Color.BLACK)
    message_label.add_theme_constant_override("shadow_offset_x", 1)
    message_label.add_theme_constant_override("shadow_offset_y", 1)
    message_layer.add_child(message_label)
    message_label.text = "TEST ROOM // REACH THE FAR RIGHT"
    var timer = get_tree().create_timer(2.2)
    timer.timeout.connect(func():
        if message_label != null and not stage_complete:
            message_label.text = ""
    )

func _on_player_died(_dead_player):
    if handling_death:
        return
    handling_death = true
    var has_lives = GameState.lose_life()
    if has_lives:
        message_label.text = "LIFE LOST // CHECKPOINT RESPAWN"
        await get_tree().create_timer(0.75).timeout
        player.respawn_at(GameState.checkpoint_position)
        message_label.text = ""
        handling_death = false
    else:
        message_label.text = "GAME OVER // UNLIMITED CONTINUE // STAGE RESTART"
        await get_tree().create_timer(1.35).timeout
        GameState.continue_stage()
        get_tree().reload_current_scene()

func _complete_test_room():
    if stage_complete:
        return
    stage_complete = true
    SaveManager.mark_stage_completed("test_room")
    SaveManager.submit_high_score("test_room", GameState.score)
    message_label.text = "TEST ROOM COMPLETE // SCORE SAVED"
    await get_tree().create_timer(2.0).timeout
    get_tree().change_scene_to_file("res://scenes/title_screen.tscn")
