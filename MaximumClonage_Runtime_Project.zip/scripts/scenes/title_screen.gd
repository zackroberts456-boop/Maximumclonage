extends Control

var start_button
var difficulty_button
var difficulty_order = ["easy", "normal", "hard"]

func _ready():
    _build_ui()
    grab_focus()

func _process(_delta):
    if InputRouter.is_action_just_pressed_mc("start") or InputRouter.is_action_just_pressed_mc("fire") or InputRouter.is_action_just_pressed_mc("jump"):
        _start_game()

func _build_ui():
    var background = TextureRect.new()
    background.texture = load("res://assets/ui/title_240x160.png")
    background.position = Vector2.ZERO
    background.size = Vector2(240, 160)
    background.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(background)

    var shade = ColorRect.new()
    shade.position = Vector2(4, 108)
    shade.size = Vector2(94, 48)
    shade.color = Color(0.0, 0.0, 0.0, 0.78)
    add_child(shade)

    start_button = _make_button(Vector2(9, 114), Vector2(84, 15), "START GAME")
    start_button.pressed.connect(_start_game)
    difficulty_button = _make_button(Vector2(9, 132), Vector2(84, 15), "")
    difficulty_button.pressed.connect(_cycle_difficulty)
    _refresh_difficulty_text()

    var version = Label.new()
    version.text = "MASTER FOUNDATION v0.1.0"
    version.position = Vector2(112, 148)
    version.size = Vector2(124, 9)
    version.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    version.add_theme_font_size_override("font_size", 6)
    version.add_theme_color_override("font_color", Color(0.75, 1.0, 0.55))
    add_child(version)

    start_button.grab_focus()

func _make_button(pos, button_size, text_value):
    var button = Button.new()
    button.position = pos
    button.size = button_size
    button.text = text_value
    button.add_theme_font_size_override("font_size", 8)
    button.add_theme_color_override("font_color", Color(0.82, 1.0, 0.60))
    button.add_theme_color_override("font_hover_color", Color.WHITE)
    button.add_theme_color_override("font_focus_color", Color.WHITE)
    var normal = StyleBoxFlat.new()
    normal.bg_color = Color(0.03, 0.05, 0.04, 0.90)
    normal.border_color = Color(0.25, 0.50, 0.24, 0.9)
    normal.set_border_width_all(1)
    var focus = normal.duplicate()
    focus.border_color = Color(0.65, 1.0, 0.15, 1.0)
    focus.set_border_width_all(2)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("hover", focus)
    button.add_theme_stylebox_override("focus", focus)
    button.add_theme_stylebox_override("pressed", focus)
    add_child(button)
    return button

func _cycle_difficulty():
    var index = difficulty_order.find(GameState.difficulty)
    index = (index + 1) % difficulty_order.size()
    GameState.set_difficulty(difficulty_order[index])
    _refresh_difficulty_text()

func _refresh_difficulty_text():
    if difficulty_button != null:
        difficulty_button.text = "DIFFICULTY: %s" % GameState.difficulty.to_upper()

func _start_game():
    get_tree().change_scene_to_file("res://scenes/character_select.tscn")
