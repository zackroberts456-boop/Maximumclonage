extends CanvasLayer

var player
var panel
var label

func setup(target_player):
    player = target_player

func _ready():
    layer = 50
    panel = ColorRect.new()
    panel.position = Vector2(102, 36)
    panel.size = Vector2(134, 58)
    panel.color = Color(0.0, 0.0, 0.0, 0.72)
    panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(panel)
    label = Label.new()
    label.position = Vector2(4, 3)
    label.size = Vector2(126, 52)
    label.add_theme_font_size_override("font_size", 6)
    label.add_theme_color_override("font_color", Color(0.4, 1.0, 0.45))
    panel.add_child(label)

func _process(_delta):
    if InputRouter.is_action_just_pressed_mc("debug_overlay"):
        GameState.debug_overlay_visible = not GameState.debug_overlay_visible
    if InputRouter.is_action_just_pressed_mc("debug_collision"):
        GameState.debug_collision_visible = not GameState.debug_collision_visible
    if InputRouter.is_action_just_pressed_mc("debug_touch") and not OS.has_feature("mobile"):
        GameState.touch_controls_visible = not GameState.touch_controls_visible
    visible = GameState.debug_overlay_visible
    if player == null:
        return
    var fps = Engine.get_frames_per_second()
    var move = InputRouter.get_move_vector()
    var pads = Input.get_connected_joypads().size()
    label.text = "FPS %d  PAD %d\nPOS %d,%d  VEL %d,%d\nAIM %.2f,%.2f MOVE %d,%d\nSTATE %s  HP %d/%d\nF2 HITBOX  F3 DEBUG  F4 TOUCH" % [
        fps, pads,
        int(player.global_position.x), int(player.global_position.y), int(player.velocity.x), int(player.velocity.y),
        player.aim_direction.x, player.aim_direction.y, int(move.x), int(move.y),
        str(player.sprite.animation), GameState.current_hp, GameState.max_hp
    ]
