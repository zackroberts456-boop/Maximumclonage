extends CanvasLayer

var player
var health_segments = []
var name_label
var lives_label
var score_label
var combo_label
var weapon_label

func setup(target_player):
    player = target_player

func _ready():
    layer = 20
    var root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)

    name_label = _make_label(root, Vector2(4, 3), Vector2(70, 10), "")
    lives_label = _make_label(root, Vector2(4, 15), Vector2(55, 9), "")
    score_label = _make_label(root, Vector2(157, 3), Vector2(79, 9), "")
    score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    combo_label = _make_label(root, Vector2(174, 14), Vector2(62, 9), "")
    combo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    weapon_label = _make_label(root, Vector2(72, 3), Vector2(82, 9), "")
    weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

    for i in range(16):
        var segment = ColorRect.new()
        segment.position = Vector2(4 + i * 5, 26)
        segment.size = Vector2(4, 4)
        segment.mouse_filter = Control.MOUSE_FILTER_IGNORE
        root.add_child(segment)
        health_segments.append(segment)

func _process(_delta):
    if player == null:
        return
    name_label.text = str(player.character_data.get("display_name", "PLAYER"))
    lives_label.text = "LIVES %d" % GameState.lives
    score_label.text = "%06d" % GameState.score
    combo_label.text = "COMBO x%d" % GameState.combo_multiplier
    var special = player.get_special_weapon()
    weapon_label.text = "SPECIAL: %s" % (special.to_upper() if special != "" else "NONE")
    for i in range(health_segments.size()):
        var segment = health_segments[i]
        segment.visible = i < GameState.max_hp
        segment.color = Color(0.55, 1.0, 0.1, 0.95) if i < GameState.current_hp else Color(0.12, 0.17, 0.12, 0.85)

func _make_label(parent, pos, label_size, text_value):
    var label = Label.new()
    label.position = pos
    label.size = label_size
    label.text = text_value
    label.add_theme_font_size_override("font_size", 7)
    label.add_theme_color_override("font_color", Color(0.82, 1.0, 0.70))
    label.add_theme_color_override("font_shadow_color", Color.BLACK)
    label.add_theme_constant_override("shadow_offset_x", 1)
    label.add_theme_constant_override("shadow_offset_y", 1)
    parent.add_child(label)
    return label
