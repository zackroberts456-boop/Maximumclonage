extends Control

const DPAD_CENTER = Vector2(42, 119)
const DPAD_RADIUS = 36.0
const BUTTONS = {
    "fire": {"center": Vector2(214, 121), "radius": 18.0},
    "jump": {"center": Vector2(174, 132), "radius": 18.0},
    "special": {"center": Vector2(209, 78), "radius": 16.0}
}

var active_touches = {}

func _ready():
    position = Vector2.ZERO
    size = Vector2(240, 160)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_process_input(true)
    queue_redraw()

func _process(_delta):
    visible = GameState.touch_controls_visible
    queue_redraw()

func _input(event):
    if not visible:
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            _press_touch(event.index, event.position)
        else:
            _release_touch(event.index)
    elif event is InputEventScreenDrag:
        _move_touch(event.index, event.position)

func _press_touch(index, pos):
    if pos.x < 95.0:
        active_touches[index] = {"type": "dpad"}
        _update_dpad(pos)
        return
    for action_name in BUTTONS.keys():
        var data = BUTTONS[action_name]
        if pos.distance_to(data["center"]) <= float(data["radius"]):
            active_touches[index] = {"type": "button", "action": action_name}
            InputRouter.set_touch_action(action_name, true)
            return

func _move_touch(index, pos):
    if not active_touches.has(index):
        _press_touch(index, pos)
        return
    var touch = active_touches[index]
    if touch["type"] == "dpad":
        _update_dpad(pos)

func _release_touch(index):
    if not active_touches.has(index):
        return
    var touch = active_touches[index]
    if touch["type"] == "dpad":
        InputRouter.set_touch_move(Vector2.ZERO)
    elif touch["type"] == "button":
        InputRouter.set_touch_action(touch["action"], false)
    active_touches.erase(index)

func _update_dpad(pos):
    var delta = pos - DPAD_CENTER
    if delta.length() < 8.0:
        InputRouter.set_touch_move(Vector2.ZERO)
        return
    var angle = atan2(delta.y, delta.x)
    var sector = int(round(angle / (PI / 4.0)))
    var dir = Vector2.ZERO
    match sector:
        0: dir = Vector2(1, 0)
        1: dir = Vector2(1, 1)
        2: dir = Vector2(0, 1)
        3: dir = Vector2(-1, 1)
        4, -4: dir = Vector2(-1, 0)
        -3: dir = Vector2(-1, -1)
        -2: dir = Vector2(0, -1)
        -1: dir = Vector2(1, -1)
    InputRouter.set_touch_move(dir)

func _draw():
    if not visible:
        return
    var plate = Color(0.05, 0.08, 0.06, 0.52)
    var edge = Color(0.55, 1.0, 0.2, 0.60)
    draw_circle(DPAD_CENTER, DPAD_RADIUS, plate)
    draw_line(DPAD_CENTER + Vector2(-25, 0), DPAD_CENTER + Vector2(25, 0), edge, 10.0)
    draw_line(DPAD_CENTER + Vector2(0, -25), DPAD_CENTER + Vector2(0, 25), edge, 10.0)
    draw_circle(DPAD_CENTER, 8.0, Color(0.03, 0.04, 0.03, 0.75))
    for action_name in BUTTONS.keys():
        var data = BUTTONS[action_name]
        var center = data["center"]
        var radius = float(data["radius"])
        draw_circle(center, radius, plate)
        draw_arc(center, radius, 0.0, TAU, 24, edge, 1.0)
        var mark = "F" if action_name == "fire" else ("J" if action_name == "jump" else "S")
        draw_string(ThemeDB.fallback_font, center + Vector2(-3, 3), mark, HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color.WHITE)
