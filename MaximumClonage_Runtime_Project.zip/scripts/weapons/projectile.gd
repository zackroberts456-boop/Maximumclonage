extends Area2D

var velocity = Vector2.ZERO
var damage = 1
var team = "player"
var lifetime = 2.0

func setup(direction, speed, damage_amount, projectile_team):
    velocity = direction.normalized() * float(speed)
    damage = int(damage_amount)
    team = projectile_team

func _ready():
    monitoring = true
    monitorable = true
    collision_layer = 8 if team == "player" else 16
    collision_mask = (1 | 4) if team == "player" else (1 | 2)

    var sprite = Sprite2D.new()
    sprite.texture = load("res://assets/ui/player_bullet.png" if team == "player" else "res://assets/ui/enemy_bullet.png")
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    add_child(sprite)

    var shape_node = CollisionShape2D.new()
    var shape = RectangleShape2D.new()
    shape.size = Vector2(6, 4)
    shape_node.shape = shape
    add_child(shape_node)
    body_entered.connect(_on_body_entered)

func _physics_process(delta):
    global_position += velocity * delta
    lifetime -= delta
    if lifetime <= 0.0:
        queue_free()

func _on_body_entered(body):
    if team == "player" and body.is_in_group("enemies"):
        if body.has_method("take_damage"):
            body.take_damage(damage, global_position)
        queue_free()
        return
    if team == "enemy" and body.is_in_group("players"):
        if body.has_method("take_damage"):
            body.take_damage(damage, global_position)
        queue_free()
        return
    if not body.is_in_group("players") and not body.is_in_group("enemies"):
        queue_free()
