extends Node

const Projectile = preload("res://scripts/weapons/projectile.gd")

var owner_actor
var default_cooldown = 0.18
var default_damage = 1
var default_timer = 0.0
var special_timer = 0.0
var special_weapon = ""

func configure(actor, fire_interval, projectile_damage):
    owner_actor = actor
    default_cooldown = float(fire_interval)
    default_damage = int(projectile_damage)

func _process(delta):
    default_timer = max(0.0, default_timer - delta)
    special_timer = max(0.0, special_timer - delta)

func fire_default(direction):
    if owner_actor == null or default_timer > 0.0:
        return false
    default_timer = default_cooldown
    _spawn_projectile(direction, 205.0, default_damage)
    return true

func fire_special(direction):
    if special_weapon == "" or special_timer > 0.0:
        return false
    if special_weapon == "spread":
        special_timer = 0.34
        _spawn_projectile(direction.rotated(deg_to_rad(-15.0)), 190.0, 1)
        _spawn_projectile(direction, 200.0, 1)
        _spawn_projectile(direction.rotated(deg_to_rad(15.0)), 190.0, 1)
        return true
    return false

func equip_special(weapon_id):
    special_weapon = str(weapon_id)

func clear_special():
    special_weapon = ""

func _spawn_projectile(direction, speed, damage_amount):
    var projectile = Projectile.new()
    projectile.setup(direction, speed, damage_amount, "player")
    get_tree().current_scene.add_child(projectile)
    var muzzle_offset = direction.normalized() * 12.0 + Vector2(0, -8)
    projectile.global_position = owner_actor.global_position + muzzle_offset
