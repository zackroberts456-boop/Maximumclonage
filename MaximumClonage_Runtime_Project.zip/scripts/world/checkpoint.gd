extends Area2D

var activated = false
var respawn_position = Vector2.ZERO

func setup(position_value):
    respawn_position = position_value

func _ready():
    collision_layer = 0
    collision_mask = 2
    var shape_node = CollisionShape2D.new()
    var shape = RectangleShape2D.new()
    shape.size = Vector2(12, 54)
    shape_node.shape = shape
    add_child(shape_node)
    body_entered.connect(_on_body_entered)
    queue_redraw()

func _on_body_entered(body):
    if activated or not body.is_in_group("players"):
        return
    activated = true
    GameState.set_checkpoint(respawn_position)
    queue_redraw()

func _draw():
    var color = Color(0.7, 1.0, 0.1, 0.95) if activated else Color(0.2, 0.8, 0.25, 0.65)
    draw_line(Vector2(0, -27), Vector2(0, 27), color, 2.0)
    draw_line(Vector2(-5, -20), Vector2(5, -20), color, 1.0)
    draw_circle(Vector2(0, -20), 3.0, color)
