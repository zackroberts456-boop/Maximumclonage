extends Area2D

var weapon_id = "spread"

func _ready():
    collision_layer = 0
    collision_mask = 2
    var sprite = Sprite2D.new()
    sprite.texture = load("res://assets/ui/spread_pickup.png")
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    add_child(sprite)
    var shape_node = CollisionShape2D.new()
    var shape = CircleShape2D.new()
    shape.radius = 7.0
    shape_node.shape = shape
    add_child(shape_node)
    body_entered.connect(_on_body_entered)

func _process(_delta):
    rotation += 0.025

func _on_body_entered(body):
    if body.is_in_group("players") and body.has_method("equip_special"):
        body.equip_special(weapon_id)
        queue_free()
