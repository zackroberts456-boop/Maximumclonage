from pathlib import Path
from PIL import Image
import json, hashlib

ROOT = Path('/mnt/data/MaximumClonage_Godot_Master')
PLAYERS = ['nada','bella','andre','lawrence','vance','zack']
FRAME_W, FRAME_H = 224, 160
COLS, ROWS = 10, 8
manifest = {
    'format_version': 1,
    'frame_size': [FRAME_W, FRAME_H],
    'grid': [COLS, ROWS],
    'frame_count': 80,
    'players': {}
}
for name in PLAYERS:
    src = ROOT / 'assets' / 'source_archive' / 'player_originals' / f'{name}_runtime_80frames.png'
    im = Image.open(src).convert('RGBA')
    if im.size != (FRAME_W*80, FRAME_H):
        raise SystemExit(f'{src}: expected {(FRAME_W*80, FRAME_H)}, got {im.size}')
    packed = Image.new('RGBA', (FRAME_W*COLS, FRAME_H*ROWS), (0,0,0,0))
    frame_hashes = []
    for i in range(80):
        frame = im.crop((i*FRAME_W,0,(i+1)*FRAME_W,FRAME_H))
        x = (i % COLS) * FRAME_W
        y = (i // COLS) * FRAME_H
        packed.paste(frame, (x,y))
        frame_hashes.append(hashlib.sha256(frame.tobytes()).hexdigest())
    out = ROOT / 'assets' / 'players' / f'{name}_runtime_80frames_packed.png'
    packed.save(out, optimize=True)
    # verify exact pixel identity after save
    verify = Image.open(out).convert('RGBA')
    for i in range(80):
        x=(i%COLS)*FRAME_W; y=(i//COLS)*FRAME_H
        frame=verify.crop((x,y,x+FRAME_W,y+FRAME_H))
        if hashlib.sha256(frame.tobytes()).hexdigest() != frame_hashes[i]:
            raise SystemExit(f'frame mismatch after packing: {name} {i}')
    manifest['players'][name] = {
        'source': f'assets/players/{name}_runtime_80frames.png',
        'runtime': f'assets/players/{name}_runtime_80frames_packed.png',
        'source_size': list(im.size),
        'runtime_size': list(packed.size),
        'sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
        'frame_hashes': frame_hashes,
    }

(ROOT/'assets'/'players'/'runtime_atlas_manifest.json').write_text(json.dumps(manifest, indent=2))
print('Packed six 80-frame atlases into 10x8 sheets; all 480 frame pixel hashes verified.')
