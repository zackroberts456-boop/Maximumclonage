#!/usr/bin/env bash
set -euo pipefail
GODOT_BIN="${GODOT_BIN:-godot}"
"$GODOT_BIN" --headless --path "$(cd "$(dirname "$0")/.." && pwd)" --script res://tests/foundation_smoke_test.gd
