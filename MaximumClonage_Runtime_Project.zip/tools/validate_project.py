#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from PIL import Image
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
ERRORS=[]
WARNINGS=[]
CHECKS=[]

def ok(msg): CHECKS.append(msg)
def fail(msg): ERRORS.append(msg)
def warn(msg): WARNINGS.append(msg)

def require(path):
    p=ROOT/path
    if not p.exists(): fail(f'missing required file: {path}')
    else: ok(f'exists: {path}')
    return p

required = [
    'project.godot',
    'scenes/boot.tscn','scenes/title_screen.tscn','scenes/character_select.tscn','scenes/test_room.tscn',
    'scripts/core/input_router.gd','scripts/core/game_state.gd','scripts/core/save_manager.gd','scripts/core/audio_manager.gd',
    'scripts/data/game_rules.gd','scripts/data/character_database.gd',
    'scripts/actors/player.gd','scripts/actors/test_enemy.gd',
    'scripts/components/health_component.gd','scripts/weapons/projectile.gd','scripts/weapons/weapon_controller.gd',
    'scripts/world/checkpoint.gd','scripts/world/weapon_pickup.gd',
    'scripts/ui/hud.gd','scripts/ui/debug_overlay.gd','scripts/ui/touch_controls.gd',
    'assets/environment/lab_tiles_16.png','assets/environment/lab_panel_240x160.png','assets/ui/title_240x160.png',
    'DEVELOPMENT.md','MASTER_RULES.md','ASSET_PIPELINE.md'
]
for x in required: require(x)

project=(ROOT/'project.godot').read_text()
for token in [
    'viewport_width=240','viewport_height=160','window/stretch/mode="viewport"',
    'window/stretch/scale_mode="integer"','default_texture_filter=0',
    'run/main_scene="res://scenes/boot.tscn"'
]:
    if token not in project: fail(f'project setting missing: {token}')
    else: ok(f'project setting: {token}')

excluded=['1000073021.jpg','1000073019.jpg','1000073017.jpg','1000073015.jpg','1000073013.jpg','1000073011.jpg']
for name in excluded:
    hits=[p for p in ROOT.rglob(name) if 'ASSET_PIPELINE.md' not in str(p)]
    if hits: fail(f'excluded screenshot present in project files: {name}: {hits}')
    else: ok(f'excluded screenshot absent: {name}')

# Resolve every static res:// path in project/scripts/scenes.
texts=[]
for pattern in ('*.gd','*.tscn'):
    texts.extend(ROOT.rglob(pattern))
texts.append(ROOT/'project.godot')
for f in texts:
    text=f.read_text(errors='replace')
    for res in re.findall(r'res://[^"\'\s\)]+', text):
        rel=res[6:]
        if not (ROOT/rel).exists(): fail(f'{f.relative_to(ROOT)} references missing {res}')
ok('static res:// references checked')

# Packed player atlas validation.
manifest_path=require('assets/players/runtime_atlas_manifest.json')
if manifest_path.exists():
    manifest=json.loads(manifest_path.read_text())
    if manifest.get('frame_count') != 80: fail('runtime atlas manifest frame_count != 80')
    for name in ['nada','bella','andre','lawrence','vance','zack']:
        runtime=ROOT/manifest['players'][name]['runtime']
        source=ROOT/'assets/source_archive/player_originals'/f'{name}_runtime_80frames.png'
        if not runtime.exists() or not source.exists():
            fail(f'missing source/runtime atlas for {name}'); continue
        rim=Image.open(runtime).convert('RGBA')
        sim=Image.open(source).convert('RGBA')
        if rim.size != (2240,1280): fail(f'{name} packed atlas wrong size {rim.size}')
        if sim.size != (17920,160): fail(f'{name} source atlas wrong size {sim.size}')
        for i in range(80):
            src=sim.crop((i*224,0,(i+1)*224,160))
            x=(i%10)*224; y=(i//10)*160
            dst=rim.crop((x,y,x+224,y+160))
            if hashlib.sha256(src.tobytes()).digest() != hashlib.sha256(dst.tobytes()).digest():
                fail(f'{name} frame {i} does not match packed source')
                break
        else:
            ok(f'{name}: 80 packed frames pixel-identical')

# Core-rule assertions.
rules=(ROOT/'scripts/data/game_rules.gd').read_text()
for token in ['"easy": {','"hp": 16','"normal": {','"hp": 12','"hard": {','"hp": 10','"nightmare": {','"hp": 8','PLAYER_INVULNERABILITY = 1.0','COYOTE_TIME = 0.10','JUMP_BUFFER_TIME = 0.12','COMBO_MAX = 5']:
    if token not in rules: fail(f'canonical rule token missing: {token}')
    else: ok(f'rule encoded: {token}')

controls=(ROOT/'scripts/ui/touch_controls.gd').read_text()
for token in ['"fire"','"jump"','"special"','DPAD_CENTER','InputEventScreenTouch','InputEventScreenDrag']:
    if token not in controls: fail(f'touch control token missing: {token}')
    else: ok(f'touch control encoded: {token}')

player=(ROOT/'scripts/actors/player.gd').read_text()
for token in ['GameRules.STANDARD_HITBOX_SIZE','GameRules.COYOTE_TIME','GameRules.JUMP_BUFFER_TIME','is_action_pressed_mc("fire")','_get_valid_aim','weapons.fire_default','weapons.fire_special']:
    if token not in player: fail(f'player foundation token missing: {token}')
    else: ok(f'player behavior encoded: {token}')

# Basic delimiter sanity (not a replacement for the Godot parser).
for f in ROOT.rglob('*.gd'):
    text=f.read_text()
    for a,b in [('(',')'),('[',']'),('{','}')]:
        if text.count(a)!=text.count(b): fail(f'{f.relative_to(ROOT)} unbalanced {a}{b}: {text.count(a)} vs {text.count(b)}')
ok('GDScript delimiter sanity checked')

print(f'Maximum Clonage project validation: {len(CHECKS)} checks, {len(WARNINGS)} warnings, {len(ERRORS)} errors')
for m in WARNINGS: print('WARN:',m)
for m in ERRORS: print('ERROR:',m)
if ERRORS:
    sys.exit(1)
print('PASS')
